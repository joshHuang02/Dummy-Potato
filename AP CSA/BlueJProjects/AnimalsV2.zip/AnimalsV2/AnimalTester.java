
public class AnimalTester
{
    public static void main() {
        Nose nose1 = new Nose("nose1", 3);
        System.out.println(nose1.action1());
        System.out.println(nose1.toString());
    }
}
